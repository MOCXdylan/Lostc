Icons adapted from the Noun Project:

Nation icon/Undead promotion: [Skull by Vladimir Belochkin](https://thenounproject.com/term/Skull/1030702/)

Arms Merchant: [dollar target by Rockicon](https://thenounproject.com/term/dollar-target/472861/)

Infection: [Biohazard by LUTFI GANI AL ACHMAD](https://thenounproject.com/term/Biohazard/2850224)

National Tombstone/Hard to Kill Twice: [Grave by Kmg Design](https://thenounproject.com/term/Grave/2888956)

Germ Warfare/Sickening Plague: [virus by Nawicon](https://thenounproject.com/term/virus/3364091)

Black Death: [Death by tulpahn](https://thenounproject.com/term/death/2064459/)

Ghost: [Ghost by Dmitry Baranovskiy](https://thenounproject.com/term/ghost/7897/)

Lich King/Summon the Lich King: [Crown by Vladimir Belochkin](https://thenounproject.com/term/Crown/891413) and [Skull by Vivian Ziereisen](https://thenounproject.com/term/skull/29715/)

Lich King's Tomb: [Ankara by ProSymbols](https://thenounproject.com/term/ankara/2247204/)

Graveyard: [graveyard by Nikita Kozin](https://thenounproject.com/term/graveyard/573169)

Memento Mori: [Tombstone by Sneha](https://thenounproject.com/term/tombstone/2915140/)

Abyss: [canyon by iconfield](https://thenounproject.com/term/canyon/3005193/)

Bone Dragon: [dragon by BGBOXXX Design](https://thenounproject.com/term/dragon/1646686/)

Necromancer: [necromancy by HeadsOfBirds](https://thenounproject.com/term/necromancy/1178598/)

Mass Grave: [Mass Grave by Dan Hetteix](https://thenounproject.com/term/mass-grave/75126/)

Tasty Brains: [Brain by AFY Studio](https://thenounproject.com/term/brain/1455525/)

Breach the Walls: [disruptor by Luis Prado](https://thenounproject.com/term/disruptor/2640915/)

Eat the Living: [fork and knife by John Winowiecki](https://thenounproject.com/term/fork-and-knife/3415220/)

Angel of Death: [wings by Luis Prado](https://thenounproject.com/term/wings/51806/)

Morgue: [morgue by MonoGraphic, ES](https://thenounproject.com/term/morgue/3836271/)

Gravedigger: [Shovel by Milinda Courey](https://thenounproject.com/term/shovel/231777/)

Pixel art:

Graveyard and Abyss tile improvements by ekids789789#4813 on Discord

Arms Merchant, Black Death, Bone Dragon, Ghost, Warrior-Undead and Lich King units by GeneralWadaling#2878 on Discord

All other pixel art based on units by GeneralWadaling#2878 with minor modifications by Lodo the Bear