A zombie plague has broken out in the world of Unciv... and if you like, you can be the zombies! Devour and conquer the world with your tireless flesh-eating army!

There's a catch, though: the undead cannot build. They can only infect (and they're not so great at trading). Your only way to acquire new cities is to conquer them. Fortunately, you're pretty good at that.

About this mod: The Undead are designed to be very, very different from your average UnCiv civilization. They cannot build Settlers to settle new cities, they cannot generate Great Merchants to conduct trade missions, they're bad at culture and they're very bad at science. So what are they good at? Devouring. They build units quickly, they can sustain a large army cheaply, and they're never, ever unhappy. They roll forward without ever stopping to rest, devouring everything in their path. They are especially good at fighting cities and conquering city-states, and their short-range units heal when they kill. If you're in the mood for total war, the Undead are for you.

Be warned, though: individual zombies are weak! It's only in numbers that they are strong.